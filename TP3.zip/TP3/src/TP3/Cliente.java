package TP3;

public abstract class Cliente {
    private String nome;
    private long RG;
    private String categoria;
    private double credito;
    
    public Cliente (String nome, long RG, double credito){
        this.nome = nome;
        this.RG = RG;
        this.credito = credito;
        setCategoria();
    }
    public String getNome(){return this.nome;}
    public long getRG(){return this.RG;}
    public double getCredito(){return this.credito;}
    public String getCategoria(){return this.categoria;}
    public void setNome(String newNome){this.nome = newNome;}
    public void setCredito(double newCredito){this.credito = newCredito;}
    public abstract void setCategoria();
    
}
