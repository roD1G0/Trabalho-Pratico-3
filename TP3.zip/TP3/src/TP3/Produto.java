package TP3;

public class Produto {
    private static long geraCodigo = 10000;
    private long codigo;
    private String nome;
    private String descricao;
    private int quantidade;
    private double valorCusto;
    private double valorVenda;
    
    public Produto(String nome, String descricao, int quantidade, double valorCusto, double valorVenda){
        codigo = geraCodigo++;
        this.nome = nome;
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.valorCusto = valorCusto;
        this.valorVenda = valorVenda;
    }
    public long getCodigo(){return this.codigo;}
    public String getNome(){return this.nome;}
    public String getDescricaco(){return this.descricao;}
    public int getQuantidade(){return this.quantidade;}
    public double getValorCusto(){return this.valorCusto;}
    public double getValorVenda(){return this.valorVenda;}
    
    public void setNome(String newNome){
        this.nome = newNome;
    }
    public void setDescricao(String newDescricao){
        this.descricao = newDescricao;
    }
    
    public void setQuantidade(int newQuantidade){
        this.quantidade = newQuantidade;
    }
    public void setValorCusto(double newValorCusto){
        this.valorCusto = newValorCusto;
    }
    public void setValorVenda(double newValorVenda){
        this.valorVenda = newValorVenda;
    }

}
